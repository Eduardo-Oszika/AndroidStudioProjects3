package com.oszika.bemcalcula.util;

public class Converter {

    public static String  converterParaBinario(long valor) {
        return Long.toBinaryString(valor);
    }


}
